const Contact = () => {
  return (
    <div id='Contact'>
      Contact.jsx
      <title>contact.jsx</title>
      <div>...</div>
    </div>
  );
};

export default Contact;
