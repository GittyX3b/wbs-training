const About = () => {
  return (
    <div id='About'>
      About.jsx
      <title>about.jsx</title>
      <div>...</div>
    </div>
  );
};

export default About;
