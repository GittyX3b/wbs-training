const Home = () => {
  return (
    <div id='Home'>
      Home.jsx
      <title>home.jsx</title>
      <div>...</div>
    </div>
  );
};

export default Home;
